package com.cg.asts.exception;

public class AirSpaceException extends Exception{
	

	private static final long serialVersionUID = 1L;

	public AirSpaceException() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	public AirSpaceException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
	
}
